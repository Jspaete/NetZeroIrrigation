"""===========================================================================================================================================================================
Title:        ZEN-GARDEN
Created:      October-2021
Authors:      Alissa Ganter (aganter@ethz.ch)
Organization: Laboratory of Risk and Reliability Engineering, ETH Zurich

Description:  Scenario settings settings.
==========================================================================================================================================================================="""
scenarios = dict()
###### TRADE-OFF SCENARIOS ###############################
scenarios["0"] = {
    "EnergySystem": {
        "carbon_emissions_budget": {
            "default": "attributes_co2",
            "default_op": 0}}}

scenarios["75cost-optimal"] = {
    "EnergySystem": {
        "carbon_emissions_budget": {
            "default": "attributes_trade_off",
            "default_op": 0.75}}}

scenarios["25cost-optimal"] = {
    "EnergySystem": {
        "carbon_emissions_budget": {
            "default": "attributes_trade_off",
            "default_op": 0.25}}}

######## BAU CASE ###############################


scenarios["BAU"] = {
   "el_WP": {
       "capacity_addition_max": {
           "default": "attributes_BAU",
           "default_op": 1
       }},
    "diesel_WP": {
       "capacity_addition_max": {
           "default": "attributes_BAU",
           "default_op": 1
       }},
     "electricity": {
       "availability_import_yearly": {
           "file": "availability_import_yearly_BAU",
           "file_op": 1
       }},
        "diesel": {
         "availability_import_yearly": {
                "file": "availability_import_yearly_BAU",
                "file_op": 1
            }}}



########### UNCERTAINTY SCENARIOS #############
# conversion factor high water pump ################################################################
scenarios["0_elWP_cf_high"] = {
   "el_WP": {
       "conversion_factor": {
           "file": "conversion_factor_high_251112",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


# scenarios["100_elWP_cf_high"] = {
#    "el_WP": {
#        "conversion_factor": {
#            "file": "conversion_factor__high_251110",
#            "file_op": 1
#        }}}

scenarios["0_elWP_cf_low"] = {
   "el_WP": {
       "conversion_factor": {
           "file": "conversion_factor_low_251112",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_elWP_cf_low"] = {
   "el_WP": {
       "conversion_factor": {
           "file": "conversion_factor_low_251112",
           "file_op": 1
       }}}

# Price diesel ################################################################

scenarios["100_dieselWP_cf_high"] = {
   "diesel_WP": {
       "conversion_factor": {
           "file": "conversion_factor__high_251110",
           "file_op": 1
       }}}


scenarios["100_dieselWP_cf_low"] = {
   "diesel_WP": {
       "conversion_factor": {
           "file": "conversion_factor__low_251110",
           "file_op": 1
       }}}
#Batteries ################################################################
scenarios["100_h_bat"] = {
   "battery": {
       "capex_specific_storage_energy": {
           "default": "attributes_high",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_high",
           "default_op": 1
       }}}


scenarios["0_h_bat"] = {
   "battery": {
       "capex_specific_storage_energy": {
           "default": "attributes_high",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_high",
           "default_op": 1
       }},
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0}}}



scenarios["100_l_bat"] = {
    "battery": {
        "capex_specific_storage_energy": {
            "default": "attributes_low",
            "default_op": 1
        },
        "capex_specific_storage": {
            "default": "attributes_low",
            "default_op": 1
        }}}


scenarios["0_l_bat"] = {
   "battery": {
       "capex_specific_storage_energy": {
           "default": "attributes_low",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_low",
           "default_op": 1
       }},
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0}}}

#Water Storage ################################################################

scenarios["100_h_ws"] = {
    "water_storage": {
        "capex_specific_storage_energy": {
            "default": "attributes_high",
            "default_op": 1
        },
        "capex_specific_storage": {
            "default": "attributes_high",
            "default_op": 1
        }}}

scenarios["0_h_ws"] = {
   "water_storage": {
       "capex_specific_storage_energy": {
           "default": "attributes_high",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_high",
           "default_op": 1
       }},
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0}}}


scenarios["100_l_ws"] = {
   "water_storage": {
       "capex_specific_storage_energy": {
           "default": "attributes_low",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_low",
           "default_op": 1
       }}}


scenarios["0_l_ws"] = {
   "water_storage": {
       "capex_specific_storage_energy": {
           "default": "attributes_low",
           "default_op": 1
       },
       "capex_specific_storage": {
           "default": "attributes_low",
           "default_op": 1
       }},
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0}}}

#PV ################################################################
scenarios["0_h_pv"] = {
   "PV": {
       "capex_specific": {
           "default": "attributes_high",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


scenarios["100_h_pv"] = {
   "PV": {
       "capex_specific": {
           "default": "attributes_high",
           "default_op": 1
       }}}

scenarios["0_l_pv"] = {
   "PV": {
       "capex_specific": {
           "default": "attributes_low",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_l_pv"] = {
   "PV": {
       "capex_specific": {
           "default": "attributes_low",
           "default_op": 1
       }}}

#Diesel Water pumps ################################################################
scenarios["0_h_diesel_wp"] = {
   "diesel_WP": {
       "capex_specific": {
           "default": "attributes_high",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


scenarios["100_h_diesel_wp"] = {
    "diesel_WP": {
        "capex_specific": {
            "default": "attributes_high",
            "default_op": 1
        }}}

scenarios["0_l_diesel_wp"] = {
   "diesel_WP": {
       "capex_specific": {
           "default": "attributes_low",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_l_diesel_wp"] = {
    "diesel_WP": {
        "capex_specific": {
            "default": "attributes_low",
            "default_op": 1
        }}}

# Electric Water pumps ################################################################
scenarios["0_h_el_wp"] = {
   "el_WP": {
       "capex_specific": {
           "default": "attributes_high",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


scenarios["100_h_el_wp"] = {
   "el_WP": {
       "capex_specific": {
           "default": "attributes_high",
           "default_op": 1
       }}}

scenarios["0_l_el_wp"] = {
   "el_WP": {
       "capex_specific": {
           "default": "attributes_low",
           "default_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_l_el_wp"] = {
    "el_WP": {
        "capex_specific": {
            "default": "attributes_low",
            "default_op": 1
        }}}


# Price electricity ################################################################
scenarios["0_h_price_el"] = {
   "electricity": {
       "price_import": {
           "file": "price_import_max",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


scenarios["100_h_price_el"] = {
   "electricity": {
       "price_import": {
           "file": "price_import_max",
           "file_op": 1
       }}}

scenarios["0_l_price_el"] = {
   "electricity": {
       "price_import": {
           "file": "price_import_min",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_l_price_el"] = {
   "electricity": {
       "price_import": {
           "file": "price_import_min",
           "file_op": 1
       }}}

# Price diesel ################################################################
scenarios["0_h_price_diesel"] = {
   "diesel": {
       "price_import": {
           "file": "price_import_max",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}


scenarios["100_h_price_diesel"] = {
   "diesel": {
       "price_import": {
           "file": "price_import_max",
           "file_op": 1
       }}}

scenarios["0_l_price_diesel"] = {
   "diesel": {
       "price_import": {
           "file": "price_import_min",
           "file_op": 1
       }
   },
   "EnergySystem": {
       "carbon_emissions_budget": {
           "default": "attributes_co2",
           "default_op": 0
       }}}

scenarios["100_l_price_diesel"] = {
   "diesel": {
       "price_import": {
           "file": "price_import_min",
           "file_op": 1
       }}}